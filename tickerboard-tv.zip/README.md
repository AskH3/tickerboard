# Ticker Board

A TV stock ticker board, plus a Fire TV app that opens it full screen.

- `index.html`: the board itself, served by GitHub Pages at https://askh3.github.io/tickerboard/
- `android/`: the Fire TV app (a full-screen WebView that loads the page above)
- `.github/workflows/build.yml`: builds the app on every push and publishes it as a release

Latest app download: https://github.com/AskH3/tickerboard/releases/latest/download/tickerboard-tv.apk

To change the board, edit `index.html` and commit. The app reloads the page every 6 hours, or you can reopen it to load the update right away.
